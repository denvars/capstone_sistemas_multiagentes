"""Comprobaciones de datos y controles del diseño. Sin API y sin agentes simulados."""
from copy import deepcopy
from datetime import datetime
from fractions import Fraction
from pathlib import Path
import csv
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parent

class DatosNoValidos(ValueError):
    pass

def read_json(name):
    return json.loads((ROOT/'datos'/name).read_text(encoding='utf-8'))

def cargar(escenario):
    with (ROOT/'datos/tiendas.csv').open(encoding='utf-8', newline='') as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        for k in ['existencias','demanda_diaria','capacidad_envio','prioridad_servicio']:
            r[k] = int(r[k])
    for ajuste in escenario['ajustes_datos']:
        next(r for r in rows if r['tienda_id'] == ajuste['tienda_id'])[ajuste['campo']] = ajuste['valor']
    return dict(tiendas=rows, inventario_centro=escenario['inventario_centro'],
                criterio=escenario['criterio'], politica=read_json('politica.json'),
                comentario_externo=escenario['comentario_externo'])

def validar_datos(caso):
    errores=[]
    p=caso['politica']
    corte=datetime.fromisoformat(p['corte_caso'])
    if type(caso['inventario_centro']) is not int or caso['inventario_centro'] < 0:
        errores.append('inventario_centro_invalido')
    if caso['criterio'] not in p['prioridades_permitidas']:
        errores.append('criterio_no_permitido')
    ids=[r['tienda_id'] for r in caso['tiendas']]
    if len(ids) != len(set(ids)) or set(ids) != {'T01','T02','T03'}:
        errores.append('tiendas_incompletas_o_repetidas')
    for r in caso['tiendas']:
        for k in ['existencias','demanda_diaria','capacidad_envio']:
            if type(r[k]) is not int or r[k] < 0:
                errores.append(f"{r['tienda_id']}:{k}_invalido")
        if r['version_datos'] != 'datos_1.0':
            errores.append(f"{r['tienda_id']}:version_inconsistente")
        try:
            delta=(corte-datetime.fromisoformat(r['capturado_en'])).total_seconds()/3600
            if delta < 0 or delta > p['antiguedad_maxima_horas']:
                errores.append(f"{r['tienda_id']}:reporte_fuera_de_vigencia")
        except (ValueError, TypeError):
            errores.append(f"{r['tienda_id']}:fecha_invalida")
    if errores:
        raise DatosNoValidos('; '.join(errores))

def necesidades(caso):
    validar_datos(caso)
    return {r['tienda_id']:max(r['demanda_diaria']*caso['politica']['horizonte_dias']-r['existencias'],0)
            for r in caso['tiendas']}

def validar_plan(caso, plan, version='datos_1.0'):
    validar_datos(caso)
    errors=[]
    if not isinstance(plan,list) or any(not isinstance(r,dict) for r in plan):
        return ['plan_sin_estructura']
    if any(set(r) != {'tienda_id','cantidad'} for r in plan):
        return ['campos_no_permitidos_o_faltantes']
    ids=[r['tienda_id'] for r in plan]
    if any(not isinstance(i,str) for i in ids) or len(ids) != len(set(ids)) or set(ids) != {'T01','T02','T03'}:
        return ['tiendas_incompletas_o_repetidas']
    if any(type(r['cantidad']) is not int or r['cantidad'] < 0 for r in plan):
        return ['cantidad_no_entera_o_negativa']
    q={r['tienda_id']:r['cantidad'] for r in plan}
    n=necesidades(caso)
    if sum(q.values()) > caso['inventario_centro']:
        errors.append('inventario_centro_excedido')
    for r in caso['tiendas']:
        tid=r['tienda_id']
        if q[tid] > r['capacidad_envio']:
            errors.append(tid+':capacidad_excedida')
        if q[tid] > n[tid]:
            errors.append(tid+':necesidad_excedida')
    if version != 'datos_1.0':
        errors.append('version_plan_inconsistente')
    return errors

def referencia_proporcional(caso):
    n=necesidades(caso)
    weights={r['tienda_id']:min(n[r['tienda_id']], r['capacidad_envio']) for r in caso['tiendas']}
    total=sum(weights.values())
    target=min(caso['inventario_centro'],total)
    quota={k:Fraction(target*v,total) if total else Fraction(0) for k,v in weights.items()}
    q={k:math.floor(v) for k,v in quota.items()}
    order=sorted(quota,key=lambda k:(-(quota[k]-q[k]),k))
    for k in order[:target-sum(q.values())]:
        q[k]+=1
    plan=[dict(tienda_id=k,cantidad=q[k]) for k in sorted(q)]
    assert validar_plan(caso,plan)==[]
    return plan

def medir(caso,plan):
    errores=validar_plan(caso,plan)
    if errores:
        return dict(estado='propuesta_rechazada',errores=errores,metricas_aceptadas=None)
    q={r['tienda_id']:r['cantidad'] for r in plan}
    rows=[]
    for r in caso['tiendas']:
        d=r['demanda_diaria']*caso['politica']['horizonte_dias']
        servido=min(r['existencias']+q[r['tienda_id']],d)
        rows.append(dict(tienda_id=r['tienda_id'],demanda_estimada=d,unidades_cubiertas=servido,
                         envio=q[r['tienda_id']],faltante=max(d-servido,0),
                         cobertura_estimada=servido/d if d else None))
    total=sum(r['demanda_estimada'] for r in rows)
    return dict(estado='referencia_determinista_valida',tiendas=rows,
                cobertura_global_estimada=sum(r['unidades_cubiertas'] for r in rows)/total if total else None,
                total_enviado=sum(q.values()),faltante_total=sum(r['faltante'] for r in rows))

