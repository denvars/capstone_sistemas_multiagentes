"""Conversión de un .ipynb guardado completo a HTML/PDF, sin ejecutar sus celdas.

Basada en el flujo Drive -> nbconvert -> PDF -> descarga del profesor.
La etapa HTML conserva tablas que la conversión a LaTeX puede omitir.
El renderizador es aislado, sin JavaScript ni solicitudes de red.
"""
from pathlib import Path
import argparse
import base64
import hashlib
import json
import re

CSS = r"""
@page { size: A4; margin: 15mm 13mm 17mm; }
* { box-sizing: border-box; }
body { margin: 0; color: #233d57; font: 10pt/1.45 Arial, sans-serif; }
h1,h2,h3,h4 { color: #154e97; break-after: avoid; }
h1 { font-size: 20pt; } h2 { font-size: 15pt; } h3 { font-size: 12pt; }
p { margin: 5pt 0 8pt; } li { margin-bottom: 3pt; }
a { color: #154e97; overflow-wrap: anywhere; }
.cabecera { border-top: 6px solid #154e97; padding: 12pt 0; }
.aviso { background: #eef4fb; padding: 10pt; border-top: 3px solid #0350a1; }
.cell { margin: 15pt 0; padding: 0; break-inside: auto; }
.prompt { font: 8pt monospace; color: #60748b; margin: 6pt 0; }
.input_area { border: 1px solid #d6dfeb; background: #f5f7fa; padding: 8pt; }
pre, code { font-family: "DejaVu Sans Mono", monospace; font-size: 8pt; }
pre { white-space: pre-wrap !important; overflow-wrap: anywhere; word-break: break-word;
      max-height: none !important; overflow: visible !important; margin: 5pt 0; }
.text_cell pre { break-inside: avoid; }
.output_area, .output_subarea, .rendered_html, .inner_cell { max-width: 100% !important;
      width: auto !important; height: auto !important; max-height: none !important;
      overflow: visible !important; display: block !important; }
table { width: 100% !important; min-width: 0 !important; border-collapse: collapse;
        table-layout: fixed; font-size: 9pt; margin: 8pt 0; }
thead { display: table-header-group; } tfoot { display: table-footer-group; }
th, td { padding: 6pt; border: 1px solid #d5dfec; text-align: left;
         vertical-align: top; white-space: normal !important; overflow-wrap: anywhere; }
th { background: #154e97 !important; color: white !important; font-weight: bold; }
tr { break-inside: avoid; } caption { text-align: left; font-weight: bold; margin: 7pt 0; break-after: avoid; }
td ul,td ol { padding-left: 14pt; margin: 3pt 0; } td li { margin: 2pt 0; }
img,svg { max-width: 100% !important; height: auto !important; }
.c4 { max-width: none !important; width: 100% !important; margin: 8pt 0 !important;
      padding: 9pt !important; font: 10pt/1.45 Arial,sans-serif !important;
      border: 1px solid #d5dfec !important; box-shadow: none !important;
      background: #f6f8fc !important; overflow: visible !important; }
.c4 h2 { font-size: 13pt !important; } .c4 h3 { font-size: 11pt !important; }
.c4 .tabla, .c4 .registro-multi { overflow: visible !important; max-height: none !important; }
.c4 table { font-size: 9pt !important; table-layout: fixed !important; min-width: 0 !important; }
.c4 .registro-multi th:first-child { width: 18% !important; }
.c4 .registro-multi th:nth-child(2) { width: 22% !important; }
.c4 .registro-multi th:nth-child(3) { width: 60% !important; }
.c4 .tabla-multi th:first-child { width: 18% !important; }
.c4 .tabla-multi th:nth-child(2) { width: 22% !important; }
.c4 .tabla-multi th:nth-child(3) { width: 60% !important; }
.c4 td, .c4 th { padding: 6pt !important; }
.c4 .flujo { display: flex; flex-wrap: wrap; gap: 5pt; }
.c4 .paso { white-space: normal !important; }
details { display: block; } summary { font-weight: bold; }
.anchor-link { display: none; }
"""


def ocultar_claves(texto):
    texto = re.sub(r"\b(?:ag_|sk-)[A-Za-z0-9_-]{12,}", "[CLAVE OMITIDA]", texto)
    texto = re.sub(r"(?i)Bearer\s+[A-Za-z0-9_./+\-=]{12,}", "Bearer [CLAVE OMITIDA]", texto)
    return texto


def preparar_html(origen):
    import nbformat
    from nbconvert import HTMLExporter
    from bs4 import BeautifulSoup
    ruta = Path(origen).expanduser().resolve()
    if ruta.suffix.lower() != '.ipynb' or not ruta.is_file():
        raise FileNotFoundError(f"No existe el notebook: {ruta}. Revisen TARGET_NOTEBOOK y DRIVE_PATH.")
    raw = ruta.read_text(encoding='utf-8')
    nb = nbformat.reads(ocultar_claves(raw), as_version=4)
    # La cadena binaria de instalación no es una explicación ni una decisión del equipo.
    # Se conserva el código legible y se evita imprimir páginas de datos codificados.
    for celda in nb.cells:
        if celda.cell_type == 'code':
            celda.source = re.sub(r'^PAQUETE_INCLUIDO = "[A-Za-z0-9+/=]+"$',
                'PAQUETE_INCLUIDO = "[cadena binaria incorporada en el notebook original; omitida del PDF]"',
                celda.source, flags=re.M)
    # No ExecutePreprocessor: convertir no ejecuta ni consume tokens.
    html, _ = HTMLExporter(template_name='basic').from_notebook_node(nb)
    soup = BeautifulSoup(html, 'html.parser')
    avisos = []
    for tabla in soup.find_all('table'):
        columnas = [x.get_text(' ', strip=True) for x in tabla.select('thead th')]
        if columnas == ['Paso / rol', 'Fase', 'Resultado']:
            tabla['class'] = tabla.get('class', []) + ['tabla-multi']
    for nodo in list(soup.find_all(['script', 'iframe', 'object', 'embed', 'form', 'input', 'button', 'link', 'meta'])):
        if nodo.name in {'iframe','object','embed'}:
            avisos.append('Se omitió un componente interactivo externo; revisen su evidencia estática antes de entregar.')
        nodo.decompose()
    for nodo in soup.find_all(True):
        for attr in list(nodo.attrs):
            if attr.lower().startswith('on') or attr in {'srcset','srcdoc'}:
                del nodo[attr]
        if nodo.name == 'details':
            nodo['open'] = ''
        for attr in ('href','src','xlink:href'):
            valor = str(nodo.get(attr, ''))
            if valor.lower().startswith(('javascript:', 'file:')):
                del nodo[attr]
            elif attr == 'src' and valor and not valor.startswith(('data:image/png;base64,','data:image/jpeg;base64,','data:image/svg+xml;base64,')):
                avisos.append('Una imagen no incrustada no se incluyó. Debe estar guardada dentro del notebook.')
                del nodo[attr]
        if 'style' in nodo.attrs and re.search(r'url\s*\(|@import', nodo['style'], re.I):
            del nodo['style']
    for estilo in soup.find_all('style'):
        if re.search(r'url\s*\(|@import', estilo.get_text(), re.I):
            estilo.decompose()
    # Mantener los estilos de las tablas originales y aplicar al final solo ajustes de impresión.
    styles = ''.join(str(x.extract()) for x in list(soup.find_all('style')))
    code = [c for c in nb.cells if c.cell_type == 'code']
    outputs = [o for c in code for o in c.get('outputs', [])]
    faltantes = sum(not c.get('outputs') for c in code)
    if faltantes:
        avisos.append(f'{faltantes} celdas de código sin salida guardada; puede ser normal en definiciones o en esta celda de exportación. Verifiquen que las celdas de resultados sí tengan su salida.')
    if any(o.output_type == 'error' for o in outputs):
        avisos.append('El notebook contiene errores guardados; se conservan en el PDF para revisión, no se ocultan.')
    if any('application/vnd.jupyter.widget-view+json' in o.get('data', {}) for o in outputs):
        avisos.append('Hay widgets interactivos: el PDF solo conserva su representación estática disponible.')
    from html import escape
    aviso = ''.join('<li>'+escape(a)+'</li>' for a in dict.fromkeys(avisos))
    cabecera = ('<header class="cabecera"><h1>Capstone · Notebook completo</h1>'
                '<p>Código, explicaciones y resultados guardados de la ejecución. Se omite únicamente la cadena binaria de instalación incorporada en el archivo original.</p>'
                '<p>Archivo fuente: '+escape(ruta.name)+'</p></header>'
                '<div class="aviso">Esta exportación no ejecuta celdas ni consulta Luna. '
                'Incluye las salidas que estaban guardadas, no resultados pendientes ni archivos externos. '
                'Este PDF conserva evidencia del notebook para los apéndices de la presentación. La entrega se organiza conforme a la consigna del capstone.'
                + ('<ul>'+aviso+'</ul>' if aviso else '') + '</div>')
    html = ('<!doctype html><html lang="es"><head><meta charset="utf-8"><title>Capstone - Notebook completo</title>'
            +styles+'<style>'+CSS+'</style></head><body>'+cabecera+str(soup)+'</body></html>')
    stats = {'fuente':str(ruta), 'sha256_fuente':hashlib.sha256(raw.encode()).hexdigest(),
             'celdas':len(nb.cells), 'celdas_codigo':len(code), 'salidas':len(outputs),
             'salidas_html':sum('text/html' in o.get('data',{}) for o in outputs),
             'tablas_html':len(soup.find_all('table')), 'avisos':list(dict.fromkeys(avisos)),
             'codigo_incluido':True, 'notebook_ejecutado_por_exportador':False}
    return html, stats


def _convertir_sin_bucle(origen, destino, navegador=None):
    from playwright.sync_api import sync_playwright
    ruta = Path(destino).expanduser().resolve()
    if ruta.suffix.lower() != '.pdf':
        raise ValueError('El destino debe terminar en .pdf.')
    ruta.parent.mkdir(parents=True, exist_ok=True)
    base = ruta
    n = 2
    while ruta.exists() or ruta.with_suffix('.html').exists():
        ruta = base.with_name(f'{base.stem}_{n}.pdf')
        n += 1
    html, stats = preparar_html(origen)
    ruta.with_suffix('.html').write_text(html, encoding='utf-8')
    with sync_playwright() as p:
        opciones = {'headless':True}
        if navegador:
            opciones['executable_path'] = str(navegador)
        with p.chromium.launch(**opciones) as browser:
            context = browser.new_context(java_script_enabled=False, offline=True)
            context.route('**/*', lambda route: route.abort())
            page = context.new_page()
            page.set_content(html, wait_until='load')
            page.emulate_media(media='print')
            page.pdf(path=str(ruta), format='A4', print_background=True, prefer_css_page_size=True,
                     display_header_footer=True, header_template='<span></span>',
                     footer_template='<div style="width:100%;text-align:right;font:8px Arial;color:#60748b;padding:0 50px">Capstone · <span class="pageNumber"></span> / <span class="totalPages"></span></div>')
    if not ruta.is_file() or not ruta.read_bytes().startswith(b'%PDF-'):
        raise RuntimeError('No se generó un PDF válido; revisen el error anterior.')
    stats['sha256_pdf'] = hashlib.sha256(ruta.read_bytes()).hexdigest()
    stats['pdf'] = str(ruta)
    ruta.with_suffix('.json').write_text(json.dumps(stats, ensure_ascii=False, indent=2), encoding='utf-8')
    return ruta, stats


def convertir(origen, destino, navegador=None):
    # Colab ya tiene un bucle asyncio. El renderizador síncrono se aísla en un hilo.
    # Solo convierte el archivo guardado; nunca ejecuta el notebook.
    import asyncio
    from concurrent.futures import ThreadPoolExecutor
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return _convertir_sin_bucle(origen, destino, navegador)
    with ThreadPoolExecutor(max_workers=1) as trabajador:
        return trabajador.submit(_convertir_sin_bucle, origen, destino, navegador).result()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('origen')
    parser.add_argument('destino')
    parser.add_argument('--navegador', default=None)
    args = parser.parse_args()
    archivo, stats = convertir(args.origen, args.destino, args.navegador)
    print('PDF creado:', archivo)
    print(f"{stats['celdas']} celdas, {stats['tablas_html']} tablas y {stats['salidas_html']} salidas HTML conservadas.")
    for aviso in stats['avisos']:
        print('REVISAR:', aviso)
