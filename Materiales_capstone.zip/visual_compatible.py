"""Salidas ejecutables de texto: no necesitan HTML, JavaScript ni recursos externos."""
import json
import textwrap
from html.parser import HTMLParser

ANCHO = 88

def texto(valor):
    if isinstance(valor, (dict, list, tuple)):
        return json.dumps(valor, ensure_ascii=False)
    return str(valor)

def lineas(valor, ancho=ANCHO):
    partes = texto(valor).splitlines() or ['']
    return [l for p in partes for l in (textwrap.wrap(p, width=ancho,
            replace_whitespace=False, drop_whitespace=True) or [''])]

def tabla(columnas, filas):
    """No omite filas/campos. Tablas anchas se presentan como fichas por registro."""
    columnas = [texto(c) for c in columnas]
    filas = [[texto(v) for v in f] for f in filas]
    if not filas:
        return '(Sin registros)'
    if any(len(f) != len(columnas) for f in filas):
        raise ValueError('La tabla tiene filas con distinta cantidad de columnas.')
    anchos = [max(len(c), *(min(32, len(v[i])) for v in filas)) for i,c in enumerate(columnas)]
    if sum(anchos) + 3*(len(columnas)-1) <= ANCHO and max(anchos) <= 32:
        borde = '-+-'.join('-'*a for a in anchos)
        salida = [' | '.join(c.ljust(a) for c,a in zip(columnas,anchos)), borde]
        for f in filas:
            partes = [lineas(v,a) for v,a in zip(f,anchos)]
            for i in range(max(map(len,partes))):
                salida.append(' | '.join((p[i] if i<len(p) else '').ljust(a) for p,a in zip(partes,anchos)))
            salida.append(borde)
    else:
        salida = []
        for i,f in enumerate(filas,1):
            salida += [f'REGISTRO {i} DE {len(filas)}', '-'*ANCHO]
            for c,v in zip(columnas,f):
                salida += [c+':'] + ['  '+l for l in lineas(v,ANCHO-2)]
            salida.append('')
    return '\n'.join(salida)

